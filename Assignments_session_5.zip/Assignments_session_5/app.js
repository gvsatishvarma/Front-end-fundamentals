//javascript Variable declaration

var name = "Satish"
var age = 38
var dob = "15/02/1976"
var pob = "Ambavarma"
console.log(name, age, dob, pob);

//javascript object literal

var empty_object = {};
var person = {name : "Satish", age : 38, dob : "15.02.1976", pob : "Ambavarma"}
var person1 = {
	"name" : "Satish", 
	"age" : 38, 
	"dob" : "15.02.1976", 
	"pob" : "Ambavarma"
}

console.log(empty_object);
console.log(person);
console.log(person1);

// Javascript nested objects

var employee = {
	name : "Satish",
	age: 38,
	salary : 80000,
	address : {
		city : "Bangalore",
		state : "Karnataka",
		pincode : 560092
	}
}

console.log("Person Name: "+employee.name+ " Age: "+employee.age+" Salary: "+employee.salary+ " Address: "+employee.address.city+ ", " + employee.address.state +", "+ employee.address.pincode);

//javascript arrays

var employees = [{
	name : "Abcd",
	age: 35,
	salary : 90000,
	address : {
		city : "Bangalore",
		state : "Karnataka",
		pincode : 560092
	}
},
{
	name : "Efgh",
	age: 30,
	salary : 100000,
	address : {
		city : "Bangalore",
		state : "Karnataka",
		pincode : 560032
	}
},
{
	name : "Ijkl",
	age: 38,
	salary : 50000,
	address : {
		city : "Bangalore",
		state : "Karnataka",
		pincode : 560024
	}
},
{
	name : "Mnop",
	age: 32,
	salary : 30000,
	address : {
		city : "Bangalore",
		state : "Karnataka",
		pincode : 560070
	}
},
{
	name : "Qrst",
	age: 28,
	salary : 120000,
	address : {
		city : "Bangalore",
		state : "Karnataka",
		pincode : 560097
	}
}];

console.log( 'This is Employee 3 Details => Name: '+ employees[2].name + ', Age: '+employees[2].age+ ', Salary: '+employees[2].salary+
	', Address: '+employees[2].address.city+', '+employees[2].address.state+', '+employees[2].address.pincode);